package printTest;

public class PrintTest1 {
	public static void main(String[] args) {
		
//		주석
//		1. 소스코드에 설명글을 작성할 때
//		2. 지금 당장 사용하지 않는 코드를 번역하고 싶지 않을 때
		
		//이름을 출력하는 부분
//		System.out.print("지우개");
//		나이를 출력하는 부분
		System.out.print("20살");
	}
}
