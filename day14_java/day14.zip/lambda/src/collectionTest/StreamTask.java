package collectionTest;

public class StreamTask {
	public static void main(String[] args) {
//		1~10까지 ArrayList에 담고 출력
//		1~100까지 중 홀수만 ArrayList에 담고 출력
//		ABCDEF를 각 문자별로 출력
//		A~F까지 ArrayList에 담고 출력
		
//		map()
//		A~F까지 중 D제외하고 ArrayList에 담고 출력
		
//		map()
//		5개의 문자열을 입력받은 후 모두 소문자로 변경(String.toLowerCase())
		
//		filter()
//		Apple, banana, Melon 중 첫번째 문자가 대문자인 문자열 출력
		
//		chars(), map(), forEach()
//		한글을 정수로 변경
//		정수를 한글로 변경
	}
}
