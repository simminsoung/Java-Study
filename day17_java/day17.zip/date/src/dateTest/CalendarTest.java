package dateTest;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class CalendarTest {
	public static void main(String[] args) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd aaa hh:mm:dd");
//		Calendar today = Calendar.getInstance();
//		System.out.println(today);
//		System.out.println(simpleDateFormat.format(today.getTime()));
		
		Calendar date = Calendar.getInstance();
//		date.set(2000, 11, 04);
//		date.set(Calendar.YEAR, 2000);
//		System.out.println(simpleDateFormat.format(date.getTime()));
//		System.out.println(date.get(Calendar.YEAR));
//		System.out.println(date.get(Calendar.MONTH) + 1);
		
		
		
	}
}
