package classTest;

public class Quiz {
//	문제, 정답, 먹이개수

}
