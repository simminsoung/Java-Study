package classTest;

public class Animal {

	void eat() {}
	
	void sleep() {}
	
//	외부에서 모든 문제를 전달받는다.
//	전달받은 문제 중 랜덤한 한 개의 문제만 리턴한다.
	void walk() {}
	
}
