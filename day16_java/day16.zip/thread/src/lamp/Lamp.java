package lamp;

/**
 * 조명 인터페이스
 */
public interface Lamp {

    void turnOn();

    void turnOff();

    boolean getPower();

}
