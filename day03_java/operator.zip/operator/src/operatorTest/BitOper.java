package operatorTest;

public class BitOper {
	public static void main(String[] args) {
		System.out.println(10 & 11);
		System.out.println(10 | 11);
		System.out.println(10 ^ 11);
		System.out.println(~10);
	}
}
