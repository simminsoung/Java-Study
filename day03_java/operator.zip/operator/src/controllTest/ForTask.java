package controllTest;

public class ForTask {
	public static void main(String[] args) {
		
//		브론즈
//		1~100까지 출력
//		100~1까지 출력
//		1~100까지 중 짝수만 출력
		
//		실버
//		1~10까지 합 출력
//		1~n까지 합 출력
		
//		골드
//		A~F까지 출력
//		A~F까지 중 C제외하고 출력
		
//		다이아
//		0 1 2 3 0 1 2 3 0 1 2 3 출력
//		aBcDeFgHiJ....Z 출력
		
	}
}
