package controllTest;

public class ForTest {
	public static void main(String[] args) {
//		이름 10번 출력
		for(int i=0; i<10; i=i+1) {
//		10~1까지 출력
			System.out.println(10 - i + ".한동석");
//			System.out.println(i + 1 + ".한동석");
		}
		
	}
}
