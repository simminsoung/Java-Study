package apiTest;

public class ApiTest {
	public static void main(String[] args) {
		Calc c = new Calc();
		c.divide(10, 3);
	}
}
