package inputTest;

public class InputTask2 {
	public static void main(String[] args) {
//		3개의 정수를 한 번에 입력받은 후
//		3개의 정수의 곱 출력
		
	}
}
