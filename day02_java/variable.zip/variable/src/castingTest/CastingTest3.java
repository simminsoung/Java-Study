package castingTest;

public class CastingTest3 {
	public static void main(String[] args) {
		System.out.println("1" + 3);
		System.out.println("1" + 3 + 8);
		System.out.println("1" + (3 + 8));
		System.out.println("1 더하기 3은 " + (1 + 3));
	}
}
