package variableTest;

public class Variable {
	public static void main(String[] args) {
		int age = 10;
		float interestRate = 3.55678F;
		double compoundInterestRate = 3.55678;
		char k_cow_grade = 'A';
		String data = "ABC";
		
		System.out.println(age);
		System.out.println(interestRate);
		System.out.println(compoundInterestRate);
		System.out.println(k_cow_grade);
		System.out.println(data);
	}
}


















