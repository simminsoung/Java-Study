package ambiguityTest;

public interface InterA {
	default void printData() {
		System.out.println("InterA");
	}
}
