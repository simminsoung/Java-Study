package ambiguityTest;

public class ClassA {
	public void printData() {
		System.out.println("ClassA");
	}
}
