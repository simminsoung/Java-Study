package ambiguityTest;

public interface InterB {
	default void printData() {
		System.out.println("InterB");
	}
}
