package markerInterfaceTest;

public class Animal {

}
