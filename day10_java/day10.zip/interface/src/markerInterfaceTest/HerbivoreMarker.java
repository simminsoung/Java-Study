package markerInterfaceTest;

// 초식
public interface HerbivoreMarker {;}
