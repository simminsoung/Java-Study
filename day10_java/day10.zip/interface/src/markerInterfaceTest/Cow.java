package markerInterfaceTest;

public class Cow extends Animal implements HerbivoreMarker{
}
