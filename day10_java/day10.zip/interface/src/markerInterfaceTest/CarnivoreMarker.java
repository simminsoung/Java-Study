package markerInterfaceTest;

// 육식
public interface CarnivoreMarker {

}
