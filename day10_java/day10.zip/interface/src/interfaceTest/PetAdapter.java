package interfaceTest;

public abstract class PetAdapter implements Pet {

	@Override
	public void bang() {;}

	@Override
	public void giveYourHand() {;}

	@Override
	public void bite() {;}

	@Override
	public void sitDown() {;}

	@Override
	public void waitNow() {;}

	@Override
	public void getNose() {;}

}
