package interfaceTest;

public interface Pet {
	final static int eyes = 2;
	int nose = 1;
	
	public abstract void bang();
	public void giveYourHand();
	public void bite();
	public void sitDown();
	public void waitNow();
	public void getNose();
}
