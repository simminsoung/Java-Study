package abstractTest;

public abstract class Electronics {
	public abstract void on();
	public abstract void off();
}
