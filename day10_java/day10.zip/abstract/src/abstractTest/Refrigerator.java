package abstractTest;

public class Refrigerator extends Electronics{

	@Override
	public void on() {
		
	}

	@Override
	public void off() {

	}

}
