package abstractTest;

public class WashingMachine extends Electronics{

	@Override
	public void on() {
		
	}

	@Override
	public void off() {
		// TODO Auto-generated method stub
		
	}

}
