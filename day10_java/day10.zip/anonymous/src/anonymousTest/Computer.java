package anonymousTest;

public class Computer {
	public static void main(String[] args) {
		Game game = new Game() {
			
			@Override
			public void play() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void exit() {
				// TODO Auto-generated method stub
				
			}
		};
	}
}
