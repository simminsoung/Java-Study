package casting;

public class Film extends Video{
	public void print4D() {
		System.out.println("4D");
	}
}
