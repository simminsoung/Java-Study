package casting;

public class Drama extends Video{
	public void sellGoods() {
		System.out.println("굿즈 판매");
	}
}
