package casting;

public class Video {

}
