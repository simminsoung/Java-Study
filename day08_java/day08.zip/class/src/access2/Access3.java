package access2;

import access1.Access1;

public class Access3 extends Access1 {
	public static void main(String[] args) {
//		Access1 a1 = new Access1();
		Access3 a3 = new Access3();
	}
}
