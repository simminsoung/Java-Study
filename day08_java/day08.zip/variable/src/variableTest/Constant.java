package variableTest;

public class Constant {
	public static void main(String[] args) {
		//수정 불가
		final int ON = 1;
		final int OFF = 0;
	}
}
