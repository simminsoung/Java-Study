package castingTest;

public class CastingTest2 {
	public static void main(String[] args) {
		char data = 68;
		System.out.println(data + 1);
	}
}
