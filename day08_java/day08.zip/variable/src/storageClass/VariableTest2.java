package storageClass;

public class VariableTest2 {
	public static void main(String[] args) {
		VariableTest vt = new VariableTest();
		VariableTest vt2 = new VariableTest();
		
		VariableTest.data_s = 500;
		System.out.println(VariableTest.data_s);

//		vt.increaseData_s();
//		vt.increaseData_s();
//		vt.increaseData_s();
//		vt.increaseData_s();
//		vt.increaseData_s();
//		vt = new VariableTest();
//		vt.increaseData_s();
//		vt.increaseData_s();
//		vt.increaseData_s();
//		vt.increaseData_s();
//		vt.increaseData_s();
		
//		vt.increaseData();
//		vt.increaseData();
//		vt.increaseData();
//		vt.increaseData();
//		vt.increaseData();
//		vt = new VariableTest();
//		vt.increaseData();
//		vt.increaseData();
//		vt.increaseData();
//		vt.increaseData();
//		vt.increaseData();
		
	}
}
