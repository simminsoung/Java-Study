package stringTest;

public class StringTask {
	public static void main(String[] args) {
//		사용자에게 입력받은 문자열 중 소문자는 모두 대문자로,
//		대문자는 모두 소문자로 변경한다.
//		length(), charAt()
		
//		정수를 한글로 변경
//		예) 1024
//		  -> 일공이사
//		charAt()
	}
}
