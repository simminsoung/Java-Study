package bakery;

public class BreadMaker implements Runnable{
	
	@Override
	public void run() {
//		빵을 20개 만든다.
	}
}
