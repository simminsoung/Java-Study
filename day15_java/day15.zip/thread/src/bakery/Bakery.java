package bakery;

public class Bakery {
	public static void main(String[] args) {
		
	}
}
