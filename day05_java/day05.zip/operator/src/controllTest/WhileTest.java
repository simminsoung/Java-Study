package controllTest;

public class WhileTest {
	public static void main(String[] args) {
		
		int count = 0;
		
		while(count != 10) {
			count++;
			System.out.println(count + ".한동석");
		}
	}
}
